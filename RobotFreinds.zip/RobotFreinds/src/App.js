import React, { useState, useEffect } from "react";
import CardList from "./Components/cardList";
import SearchBox from "./Components/SearchBox";
import './index.css';
import "remixicon/fonts/remixicon.css";
import 'tachyons';

const App = () => {
  const [state, setState] = useState({
    robots: [],
    searchfieled: "",
  });

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => response.json())
      .then((users) => setState({ ...state, robots: users }));
  }, []);

  const onsearchchange = (event) => {
    setState({ ...state, searchfieled: event.target.value });
  };

  const filteredRobots = state.robots.filter((robots) => {
    return robots.name.toLowerCase().includes(state.searchfieled.toLowerCase());
  });

  return (
    <div className="tc">
      <h1>Robots</h1>
      <SearchBox searchchange={onsearchchange} />
      <CardList robots={filteredRobots} />
    </div>
    
  );
};

export default App;

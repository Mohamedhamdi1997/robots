import React from 'react'
import { BsToggleOff, BsJustify } from "react-icons/bs";


const Navabar = () => {
  return (
  <div>
    <div className="sidenav">
    <a href="#"> <div className="logo1"><img src="../robot.jpg" alt="Logo" style={{width: '100%' }}/></div></a>
   <div className="bar"><a href="#"><BsJustify/></a></div> 
   <div className="eng"><a href="#"><BsToggleOff/></a></div>
  </div>
  </div>
  )
}

export default Navabar

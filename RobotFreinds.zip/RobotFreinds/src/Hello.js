import React, { Component } from 'react';
import './App.css';
const Hello = (props) => {
    
      return (
          <div className='f1 tc'>
               <h1>Hello world</h1>
               <p>{props.greeting}</p>
          </div>
      
      );
    }

export default Hello;